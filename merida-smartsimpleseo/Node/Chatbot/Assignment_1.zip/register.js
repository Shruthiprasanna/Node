require("babel-register");
var uncompiledFile = process.argv[2];


require(uncompiledFile);
